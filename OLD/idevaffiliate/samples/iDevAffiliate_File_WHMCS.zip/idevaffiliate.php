<?PHP

/*
Author : http://www.integration4us.com
Company that specializes in bringing together component subsystems into a whole.
For WHMCS Version 4.1.2 
*/

// --------------------------------------------------
// Define your commission type.
// 1 = One-Time Commission at signup only.
// 2 = Recurring Commissions
// --------------------------------------------------
define("IDEV_COMMISSION_TYPE",2);
// --------------------------------------------------

function idev_setaffid($vars) {

     //IDEV -- SET CLIENT AFFILIATE ID
	 
     $aidev=explode("--",$_COOKIE[idev]);    
     $sql = "update tblclients set IdevAffID='$aidev[0]' where `id`='".$vars[userid]."'";     

     if ( !mysql_query($sql))
        echo mysql_error();
}

function idev_comm_process($vars) {

    //IDEV -- COMMISSION PROCESSING
    
    if ( IDEV_COMMISSION_TYPE == 2)
       {
       $res = mysql_query("select userid,total as amount from tblinvoices where `id` ='$vars[invoiceid]'");
       $arr_order = mysql_fetch_assoc($res);
       $ordernum = $vars[invoiceid];
       }
    elseif ( IDEV_COMMISSION_TYPE == 1)
       {
       $res = mysql_query("select userid,amount from tblorders where `id` ='$vars[OrderID]'");
       $arr_order = mysql_fetch_assoc($res);
       $ordernum = $vars[OrderNumber];
       }
    else 
       {
        $res = mysql_query("select userid,amount from tblorders where `id` ='$vars[OrderID]'");
        $arr_order = mysql_fetch_assoc($res);
        $ordernum = $vars[OrderNumber];
       }   
    
    $res = mysql_query("select IdevAffID,ip from tblclients where `id` ='$arr_order[userid]'");
    $arr_client = mysql_fetch_assoc($res);
          
    $ch = curl_init();
    if ( $arr_client[IdevAffID] )
       $url = "http://www.yoursite.com/idevaffiliate/sale.php?idev_saleamt=$arr_order[amount]&idev_ordernum=$ordernum&affiliate_id=$arr_client[IdevAffID]";
    else
       $url = "http://www.yoursite.com/idevaffiliate/sale.php?idev_saleamt=$arr_order[amount]&idev_ordernum=$ordernum&ip_address=$arr_client[ip]";
    
    curl_setopt($ch, CURLOPT_URL,$url );   
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);    
}

add_hook("ClientAdd",1,"idev_setaffid");

if (IDEV_COMMISSION_TYPE == 1) {
add_hook("AfterShoppingCartCheckout",1,"idev_comm_process");
} elseif (IDEV_COMMISSION_TYPE == 2) {
add_hook("InvoicePaid",1,"idev_comm_process");
}
?>