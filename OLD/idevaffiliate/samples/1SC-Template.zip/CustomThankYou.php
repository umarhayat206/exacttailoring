<html>
<head>
<title>Thank You!</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body >

	<center>
	<h1>Thank you for your order.</h1>
	<p>Your new order ID is <?PHP echo $_POST['orderID']; ?><br />
	You will receive your receipt at <?PHP echo $_POST['email1']; ?></p>
	</center>
<table width='457'  border='0'>
  <tr>
    <td>Order ID:</td>
    <td><?PHP echo $_POST['orderID']; ?></td>
  </tr>
  <tr>
    <td>Order date: </td>
    <td>

<?PHP
print date("l");
echo ", " ;
print date("M");
echo "&nbsp;";
print date("j"); 
echo ", " ;
print date("Y");
echo "</td>";
?>

  </tr>
    <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width='200'>
	Name:<br />
	Company:<br />
	Email: 
	</td>
    <td width='247'>
	<?PHP echo $_POST['name']; ?><br />
	<?PHP echo $_POST['company']; ?><br />
	<?PHP echo $_POST['email1']; ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Address1:<br />
	Address2:<br />
	City:<br />
	State:<br />
	Zip/Postcode:<br />
	Country:<br />
	Home Phone:<br />
	Work Phone: 
	</td>
    <td>
	<?PHP echo $_POST['address1']; ?><br />
	<?PHP echo $_POST['address2']; ?><br />
	<?PHP echo $_POST['city']; ?><br />
	<?PHP echo $_POST['state']; ?><br />
	<?PHP echo $_POST['zip']; ?><br />
	<?PHP echo $_POST['country']; ?><br />
	<?PHP echo $_POST['homephone']; ?><br />
	<?PHP echo $_POST['workphone']; ?>
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td><b>Ship to:</b></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td valign='top'>
	Name:<br />
	Address1:<br />
	Address2:<br />
	City:<br />
	State:<br />
	Zip/Postcode:<br />
	Country:
	</td>
    <td>
	<?PHP echo $_POST['shipname']; ?><br />
	<?PHP echo $_POST['shipAddress1']; ?><br />
	<?PHP echo $_POST['shipAddress2']; ?><br />
	<?PHP echo $_POST['shipCity']; ?><br />
	<?PHP echo $_POST['shipState']; ?><br />
	<?PHP echo $_POST['shipZip']; ?><br />
	<?PHP echo $_POST['shipCountry']; ?>
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td valign='top'>

	<?PHP echo $_POST['product1']; ?> X <?PHP echo $_POST['quantity1']; ?><br /><br />
 	Total<br />
	<?PHP echo $_POST['shippingMethod']; ?><br />
 	State Tax<br />
 	GST<br />
 	Grand Total 
 </td>
    <td> 
	 = <?PHP echo $_POST['price1']; ?><br />
	 -----------------<br />
	 = <?PHP echo $_POST['Total']; ?> <br />
	 = <?PHP echo $_POST['shippingAmount']; ?><br />
	 = <?PHP echo $_POST['tax']; ?><br />
	 = <?PHP echo $_POST['gst']; ?><br />
	 = <b><?PHP echo $_POST['grandTotal']; ?></b>
	 </td>
  </tr>
</table>

<img border="0" src="http://www.yoursite.com/idevaffiliate/sale.php?profile=32&idev_saleamt=<?PHP echo $_POST['Total']; ?>&idev_ordernum=<?PHP echo $_POST['orderID']; ?>" width="1" height="1">

</body>
</html>