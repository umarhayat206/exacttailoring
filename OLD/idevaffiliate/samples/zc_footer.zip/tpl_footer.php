<?PHP
require(DIR_WS_MODULES . zen_get_module_directory('footer.php'));
if (!$flag_disable_footer) {
?>

<div id="navSuppWrapper">
<div id="navSupp">
<ul>
<li><?PHP echo '<a href="' . HTTP_SERVER . DIR_WS_CATALOG . '">'; ?><?PHP echo HEADER_TITLE_CATALOG; ?></a></li>
<?PHP if (EZPAGES_STATUS_FOOTER == '1' or (EZPAGES_STATUS_FOOTER == '2' and (strstr(EXCLUDE_ADMIN_IP_FOR_MAINTENANCE, $_SERVER['REMOTE_ADDR'])))) { ?>
<li><?PHP require($template->get_template_dir('tpl_ezpages_bar_footer.php',DIR_WS_TEMPLATE, $current_page_base,'templates'). '/tpl_ezpages_bar_footer.php'); ?></li>
<?PHP } ?>
</ul>
</div>
</div>
<?PHP
if (SHOW_FOOTER_IP == '1') {
?>
<div id="siteinfoIP"><?PHP echo TEXT_YOUR_IP_ADDRESS . '  ' . $_SERVER['REMOTE_ADDR']; ?></div>
<?PHP
}
?>
<?PHP
  if (SHOW_BANNERS_GROUP_SET5 != '' && $banner = zen_banner_exists('dynamic', SHOW_BANNERS_GROUP_SET5)) {
    if ($banner->RecordCount() > 0) {
?>
<div id="bannerFive" class="banners"><?PHP echo zen_display_banner('static', $banner); ?></div>
<?PHP
    }
  }
?>
<div id="siteinfoLegal" class="legalCopyright"><?PHP echo FOOTER_TEXT_BODY; ?></div>

<?PHP }

if ((int)$orders_id > 0) {
  $IDEV = $db->Execute("select class, value from " . TABLE_ORDERS_TOTAL . " where orders_id = '".(int)$orders_id."' AND class in ('ot_coupon', 'ot_subtotal', 'ot_group_pricing')");
  while (!$IDEV->EOF) {
    switch ($IDEV->fields['class']) {
      case 'ot_subtotal':
       $order_subtotal = $IDEV->fields['value'];
        break;
      case 'ot_coupon':
       $coupon_amount = $IDEV->fields['value'];
        break;
      case 'ot_group_pricing':
       $group_pricing_amount = $IDEV->fields['value'];
        break;
    }
    $IDEV->MoveNext();
  }
  $idev_sale_amount = ($order_subtotal - $coupon_amount - $group_pricing_amount);
  $idev_sale_amount = number_format($idev_sale_amount,2,'.','');

// Make sure the below path is correctly pointing to your installation folder/directory.
echo "<img border=\"0\" src=\"http://www.yourdomain.com/idevaffiliate/sale.php?idev_saleamt=$idev_sale_amount&idev_ordernum=$orders_id\" height=\"1\" width=\"1\">";

echo "</td></tr></table>";
}

?>
