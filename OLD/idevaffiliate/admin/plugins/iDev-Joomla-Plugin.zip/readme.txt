
#############################################################
## iDevAffiliate Version 5.1
## Copyright - iDevDirect.com L.L.C.
## Website: http://www.idevdirect.com/
## Support: http://www.idevsupport.com/
## Email:   support@idevdirect.com
#############################################################

IMPORTANT INFORMATION IS CONTAINED IN THIS DOCUMENT, PLEASE READ EVERYTHING!

Copyright (C) 2001-2008
iDevDirect.com L.L.C.


------------------------------------------------------------	
INSTRUCTIONS:

1. Unzip the contents of the ZIP package to your local harddrive.

2. Open the Joomla-Plugin.pdf for installation instructions.


=========================================================================================
Questions? Problems?
Visit our support forum at: http://www.idevsupport.com/
<support@idevsupport.com>
